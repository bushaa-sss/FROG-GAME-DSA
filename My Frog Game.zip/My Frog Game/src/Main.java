import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main extends Application { // We're defining our game as a special kind of application.

    private static final int WIDTH = 800;  // This sets the width of our game window.
    private static final int HEIGHT = 600; // This sets the height of our game window.
    private static final int FROG_SIZE = 50; // This sets the size of our frog character.
    private static final int CAR_WIDTH = 100; // This sets the width of cars in the game.
    private static final int CAR_HEIGHT = 50; // This sets the height of cars in the game.
    private static final int CAR_SPEED = 4;   // This determines how fast the cars move.
    private static final int CAR_SPAWN_DELAY = 60; // This controls how often cars appear.
    private static final int UPPER_CAR_BOUND = 70; // This sets the top limit for car spawning.
    private static final int LOWER_CAR_BOUND = HEIGHT - CAR_HEIGHT - 70; // This sets the bottom limit for car spawning.

    private ImageView frog;                 // This is the image of our frog character.
    private List<ImageView> cars = new ArrayList<>(); // We're using a list to store images of cars.
    private int carSpawnTimer = 0;          // This keeps track of when to spawn new cars.
    private Random random = new Random();    // We're using randomness to place cars.

    // These variables keep track of whether the game is won or lost.
    private boolean gameWon = false;
    private boolean gameOver = false;
    private Label resultLabel = new Label(""); // We can display messages using this label.

    public static void main(String[] args) {  // This is where our game starts running.
        launch(args); // We're starting our game application.
    }
    @Override
    public void start(Stage primaryStage) {  // This is where we set up the game's initial state.
        primaryStage.setTitle("Frog Game");   // We're naming our game window "Frog Game".

        Pane root = new Pane();                // This creates a blank canvas for our game.
        Scene scene = new Scene(root, WIDTH, HEIGHT); // This is where we put our game canvas.

        primaryStage.setScene(scene);          // We're putting our game canvas in the game window.

        Image roadImage = new Image("road.png"); // We're loading an image of a road.
        ImageView roadView = new ImageView(roadImage); // This displays the road image.
        roadView.setFitWidth(WIDTH);
        roadView.setFitHeight(HEIGHT);
        root.getChildren().add(roadView);       // We're adding the road to our game canvas.
        primaryStage.setTitle("Frog Game");   // This sets the window title (it's repeated).
        primaryStage.setScene(scene);          // This sets the scene in the window (it's repeated).

        frog = createFrog();  // We're creating our frog character using the createFrog method.
        root.getChildren().add(frog); // The frog appears on the game canvas.

        scene.setOnKeyPressed(event -> { // We're listening for key presses.
            if (!gameOver) { // If the game isn't over yet...
                moveFrog(event.getCode()); // ...we move the frog based on the key pressed.
            }
        });
        new AnimationTimer() { // This sets up a continuous loop for the game.
            @Override
            public void handle(long now) { // In this loop, we update the game.
                if (!gameOver && !gameWon) { // If the game isn't over and not won...
                    moveCars();     // ...we move the cars.
                    checkCollisions(); // ...we check if the frog collided with a car.
                    checkWinCondition(); // ...we check if the frog reached the top and won.
                }
            }
        }.start(); // We start the game loop.

        primaryStage.show(); // Finally, we show the game window.
    }
    private void showWinPrompt() { // This method displays a message when the player wins.
        Alert alert = new Alert(AlertType.INFORMATION); // We create a pop-up message.
        alert.setTitle("Congratulations!"); // The message is titled "Congratulations!"
        alert.setHeaderText(null);
        alert.setContentText("You won the game!"); // We're telling the player they won.
        alert.show(); // We show the message to the player.
    }
    private void showLosePrompt() { // This method displays a message when the player loses.
        Alert alert = new Alert(AlertType.ERROR); // We create a pop-up message.
        alert.setTitle("Game Over"); // The message is titled "Game Over."
        alert.setHeaderText(null);
        alert.setContentText("You lost the game!"); // We're telling the player they lost.
        alert.show(); // We show the message to the player.
    }
    private ImageView createFrog() { // This method creates our frog character.
        Image frogImage = new Image("frog.png"); // We load an image for the frog.
        ImageView frog = new ImageView(frogImage); // We create an image view for the frog.
        frog.setFitWidth(FROG_SIZE); // We set the frog's width.
        frog.setFitHeight(FROG_SIZE); // We set the frog's height.
        frog.setLayoutX(WIDTH / 2 - FROG_SIZE / 2); // We position the frog in the middle horizontally.
        frog.setLayoutY(HEIGHT - FROG_SIZE); // We position the frog at the bottom vertically.
        return frog; // We return the frog image view we created.
    }
    private void moveFrog(KeyCode key) { // Move the frog based on key presses.
        switch (key) {
            case UP:
                if (frog.getLayoutY() > 0) { // If the frog is not at the top edge...
                    frog.setLayoutY(frog.getLayoutY() - 10); // ...move it up.
                }
                break;
            case DOWN:
                if (frog.getLayoutY() < HEIGHT - FROG_SIZE) { // If the frog is not at the bottom edge...
                    frog.setLayoutY(frog.getLayoutY() + 10); // ...move it down.
                }
                break;
            case LEFT:
                if (frog.getLayoutX() > 0) { // If the frog is not at the left edge...
                    frog.setLayoutX(frog.getLayoutX() - 10); // ...move it left.
                }
                break;
            case RIGHT:
                if (frog.getLayoutX() < WIDTH - FROG_SIZE) { // If the frog is not at the right edge...
                    frog.setLayoutX(frog.getLayoutX() + 10); // ...move it right.
                }
                break;
        }
    }

    private void moveCars() { // Handle the movement of cars on the road.
        carSpawnTimer++;
        if (carSpawnTimer >= CAR_SPAWN_DELAY) {
            spawnCar(); // Spawn a new car when the timer reaches the limit.
            carSpawnTimer = 0; // Reset the timer.
        }

        List<ImageView> carsToRemove = new ArrayList<>();
        for (ImageView car : cars) {
            car.setLayoutX(car.getLayoutX() - CAR_SPEED); // Move the cars to the left.

            // Check if the car is out of bounds and remove it
            if (car.getLayoutX() + CAR_WIDTH < 0) { // If the car is off the screen...
                carsToRemove.add(car); // ...mark it for removal.
            }
        }

        cars.removeAll(carsToRemove); // Remove cars that went off the screen.
    }

    private void spawnCar() { // This method creates a new car and adds it to the game.
        Image carImage = new Image("car.png"); // Load an image for the car.
        ImageView car = new ImageView(carImage); // Create an image view for the car.
        car.setFitWidth(CAR_WIDTH); // Set the car's width.
        car.setFitHeight(CAR_HEIGHT); // Set the car's height.

        // Randomly choose a Y position within the car spawning bounds
        car.setLayoutY(random.nextInt(LOWER_CAR_BOUND - UPPER_CAR_BOUND) + UPPER_CAR_BOUND);
        car.setLayoutX(WIDTH);

        cars.add(car); // Add the car to the list of cars.
        ((Pane) frog.getParent()).getChildren().add(car); // Add the car to the game canvas.
    }
    private void checkWinCondition() { // This method checks if the player has won the game.
        if (frog.getLayoutY() <= 0) { // If the frog's Y position is at or above the top edge...
            gameWon = true; // ...the game is won.
            showWinPrompt(); // Display a message to congratulate the player.
            System.out.println("Congratulations! You won the game!"); // Print a message to the console.
        }
    }
    private void checkCollisions() { // This method checks if the frog collides with any cars.
        for (ImageView car : cars) { // Loop through all the cars on the road.
            if (frog.getBoundsInParent().intersects(car.getBoundsInParent())) {
                gameOver = true; // If the frog's bounding box intersects with a car's bounding box, the game is over.
                showLosePrompt(); // Display a message to inform the player.
                System.out.println("Game Over! You lost."); // Print a message to the console.
                break; // Exit the loop because the game is over.
            }
        }
    }
}


